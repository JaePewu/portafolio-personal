import "./App.css";

import Navbar from "./components/organisms/Navbar";
import SeccionPersonal from "./components/organisms/SeccionPersonal";
import SeccionSobreMi from "./components/organisms/SeccionSobreMi";
import SeccionExperiencia from "./components/organisms/SeccionExperiencia";
import SeccionEstudios from "./components/organisms/SeccionEstudios";
import SeccionProyectos from "./components/organisms/SeccionProyectos";

import { perfil } from "./data/perfil";
import { experiencias } from "./data/experiencias";
import { estudios } from "./data/estudios";
import { proyectos } from "./data/proyectos";

function App() {
  return (
    <>
      <header className="portada">
        <Navbar />
        <SeccionPersonal perfil={perfil} />
      </header>

      <main className="app">
        <SeccionSobreMi perfil={perfil} />

        <SeccionExperiencia experiencias={experiencias} />

        <SeccionEstudios estudios={estudios} />

        <SeccionProyectos proyectos={proyectos} />
      </main>
    </>
  );
}

export default App;
